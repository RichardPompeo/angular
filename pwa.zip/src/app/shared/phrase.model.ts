export class Phrase {
  constructor(public engPhrase: string, public ptPhrase: String) {}
}
